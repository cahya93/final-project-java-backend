package com.yanto.DB.model;

public class ResponseMessage {
	private String message;
	
	public ResponseMessage(String responseMessage){
		this.message = responseMessage;
	}
	
	public String getResponseMessage() {
		return message;
	}
}

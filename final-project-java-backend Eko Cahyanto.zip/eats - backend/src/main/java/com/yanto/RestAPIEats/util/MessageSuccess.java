package com.yanto.RestAPIEats.util;

public class MessageSuccess {

    private String MessageSuccess;

    public MessageSuccess(String successMessage){
        this.MessageSuccess = successMessage;
    }

    public String getMessageSuccess() {
        return MessageSuccess;
    }
}

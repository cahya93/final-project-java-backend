package com.yanto.rumahmakan.model;

public class Lokasi {
	int id_lokasi;
	String nama_rumah_makan;
	
	public int getId_lokasi() {
		return id_lokasi;
	}
	
	public void setId_lokasi(int id_lokasi) {
		this.id_lokasi = id_lokasi;
	}
	
	public String getNama_rumah_makan() {
		return nama_rumah_makan;
	}
	
	public void setNama_rumah_makan(String nama_rumah_makan) {
		this.nama_rumah_makan = nama_rumah_makan;
	}
}
